# Assesment-Demo-App-JSDK-orders-V2
Advanced PayPal JSDK Demo App

Thanks for taking the time and energy to review and test my PayPal Checkout Demo

This demo is written in Node.js and Ejs/Html

1. run node command: npm install  
//to install all used dependecies declared at the package.json

2. rename process.env file to .env

3. add your PayPal Sandbox credentials https://developer.paypal.com/dashboard/applications/sandbox
 set to "PAYPAL_CLIENT_ID=" and "PAYPAL_CLIENT_SECRET="

4. make sure file .npmrc is present on your workmachine

5. open you browser and naviate to http://localhost:8080/checkout or If you use VS Studio Code crtl+leftclick on the terminal underlined message: "Node server listening at http://localhost:8080/checkout

Features demonstrated JavaScript SDK:
smart buttons (styling altered)
cardfields
transaction success message on success output transactionID (entry point to check API calls)
simple error output to terminal and frontend application
captured transaction refund button 
PayLater option
DE local APM SEPA Lastschrift
Pay Now with Card button creating 
cart variables are hardcoded to the payload of purrency:EUR and purchaseUntis/amount: 100

Please consider this as educational/ demonstration project only and should never go live 
